# AFK_Kicker
Kick AFK player from your Garry's Mod server.
I have no tested this script on other valve emulator.

Put the AFK_Kicker folder in your addons fodler or directly the AFK_Kicker.lua file in **lua/autorun/server/**

You can change these variables to adjust time warning and disconnection:
```
AFK_WARN_TIME = 300
AFK_TIME = 900
```
